! python3 practical_2/word2vec.py


! python3 practical_2/sgd.py


! python3 practical_2/run.py



